#Return a string with a number of unique characters
a="abcdefgabc"
seta=set(a)
print("Unique character in the entered string is ",len(seta))

