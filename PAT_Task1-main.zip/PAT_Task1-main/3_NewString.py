#Return a string without vowels
a="Mallika"
print ("String:", a)
b=a.replace("a","").replace("e","").replace("i","").replace("o","").replace("u","")
print("Here is the New String without Vowels: ", b)