#word count
a= input("Enter the sentence: ")
print(a.count(" ")+1)
